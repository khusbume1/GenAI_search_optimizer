# Changelog

## 1.0.0 - 2026-07-13

- Added live Claude GEO audit orchestration.
- Added local demo execution.
- Added CLI, FastAPI, and Streamlit interfaces.
- Added SQLite history and per-run artifacts.
- Added score, category, summary, and finding parsing.
- Added competitor comparison.
- Added project-specific GEO implementation-plan skill.
- Added automated tests, linting, CI, and detailed documentation.
