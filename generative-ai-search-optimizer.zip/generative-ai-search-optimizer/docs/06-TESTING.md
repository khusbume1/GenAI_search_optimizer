# Testing Strategy

## Objectives

Tests protect the deterministic application layer around the non-deterministic AI workflow.

## Unit tests

### URL handling

- Adds HTTPS when omitted
- Removes fragments
- Rejects localhost
- Rejects private IP literals
- Rejects embedded credentials

### Prompt construction

- Maps application modes to the correct `/geo` command
- Rejects unsupported modes
- Includes operational safety constraints

### Report parsing

- Extracts overall score and rating
- Normalizes category names
- Extracts executive summary
- Extracts findings and severity counts

### Persistence and demo execution

- Creates an audit record
- Copies the sample report
- Writes request and result JSON
- Stores parsed fields in SQLite

## API tests

- Health endpoint responds
- Demo endpoint returns a completed audit
- Stored audit is available through history endpoints

## Running locally

```bash
pytest -q
ruff check .
```

## CI

`.github/workflows/ci.yml` runs on pushes and pull requests using Python 3.10 and 3.12.

## Why live Claude audits are not in CI

Live audits require authentication, network access, external website availability, and non-deterministic model execution. CI focuses on validation, orchestration boundaries, parsing, storage, and API behavior. Live execution should be covered by controlled integration tests in an authorized environment.
