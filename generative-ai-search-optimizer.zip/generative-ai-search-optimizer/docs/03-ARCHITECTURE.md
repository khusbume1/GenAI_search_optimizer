# Architecture

## Component diagram

```mermaid
flowchart TB
    USER[User or External System]
    CLI[CLI]
    API[FastAPI]
    UI[Streamlit]
    RUNNER[ClaudeGeoRunner]
    VALIDATOR[URL Validation]
    CLAUDE[Claude Code CLI]
    GEO[Installed /geo Skill]
    DEMO[Bundled Demo Report]
    PARSER[Report Parser]
    STORE[AuditStore]
    DB[(SQLite)]
    RUNS[(Run Directories)]

    USER --> CLI
    USER --> API
    USER --> UI
    CLI --> RUNNER
    API --> RUNNER
    UI --> RUNNER
    RUNNER --> VALIDATOR
    VALIDATOR --> RUNNER
    RUNNER -->|live| CLAUDE
    CLAUDE --> GEO
    RUNNER -->|demo| DEMO
    GEO --> RUNS
    DEMO --> RUNS
    RUNNER --> PARSER
    PARSER --> STORE
    STORE --> DB
    RUNNER --> RUNS
    DB --> CLI
    DB --> API
    DB --> UI
```

## Sequence diagram

```mermaid
sequenceDiagram
    actor User
    participant Interface as CLI/API/Dashboard
    participant Runner as ClaudeGeoRunner
    participant Store as SQLite Store
    participant Claude as Claude Code + /geo
    participant Parser as Report Parser

    User->>Interface: URL + mode
    Interface->>Runner: run(url, mode)
    Runner->>Runner: validate URL and create run directory
    Runner->>Store: insert running audit
    Runner->>Claude: invoke /geo command
    Claude-->>Runner: report files + console output
    Runner->>Parser: parse report
    Parser-->>Runner: score, categories, findings
    Runner->>Store: mark completed and persist result
    Runner-->>Interface: AuditResult
    Interface-->>User: scorecard, findings, report
```

## Module responsibilities

### `runner.py`

- Validates modes and URLs
- Creates run directories
- Writes request metadata
- Invokes Claude Code
- Handles timeout and process failures
- Discovers report files
- Coordinates parsing and storage
- Supports local demo execution

### `parser.py`

- Normalizes report labels
- Extracts score and rating
- Extracts category values from Markdown tables
- Extracts severity sections and individual findings
- Returns a typed `ParsedReport`

### `storage.py`

- Creates and migrates the SQLite table
- Records running, completed, and failed audits
- Serializes categories and findings to JSON
- Supports history and domain filtering

### Interfaces

All interfaces use the same initialized `runner` and `store` from `service.py`. This prevents business logic from being duplicated across CLI, API, and UI.

## Deployment boundaries

The portfolio version is a single-process local application. A production architecture should separate:

- API service
- Background audit workers
- Postgres database
- Object storage for reports
- Authentication service
- Scheduler for repeat audits
- Monitoring and centralized logs
