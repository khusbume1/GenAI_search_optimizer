from geo_optimizer.parser import parse_report_text

SAMPLE = """
# GEO Audit Report: Example

## Executive Summary

**Overall GEO Score: 72/100 (Fair)**

The site has a sound technical base but needs clearer answer blocks and stronger entity signals.

### Score Breakdown

| Category | Score | Weight | Weighted Score |
|---|---:|---:|---:|
| AI Citability | 64/100 | 25% | 16.0 |
| Brand Authority | 55/100 | 20% | 11.0 |
| Content E-E-A-T | 76/100 | 20% | 15.2 |
| Technical GEO | 84/100 | 15% | 12.6 |
| Schema & Structured Data | 70/100 | 10% | 7.0 |
| Platform Optimization | 68/100 | 10% | 6.8 |

## Critical Issues (Fix Immediately)

No critical issues were found.

## High Priority Issues

### Missing answer-first content
- The introduction is indirect.
- Add a concise definition.

### Weak entity relationships
- Connect Organization and Person schema.

## Medium Priority Issues
- Add visible review dates.

## Low Priority Issues
- Add llms.txt.
"""


def test_parse_report() -> None:
    parsed = parse_report_text(SAMPLE)
    assert parsed.overall_score == 72
    assert parsed.rating == "Fair"
    assert parsed.categories["AI Citability"] == 64
    assert parsed.categories["Technical GEO"] == 84
    assert "sound technical base" in parsed.summary
    assert parsed.severity_counts == {
        "critical": 0,
        "high": 2,
        "medium": 1,
        "low": 1,
    }
    assert parsed.findings[0].severity == "high"
    assert parsed.findings[0].title == "Missing answer-first content"
    assert "concise definition" in parsed.findings[0].details
