from fastapi.testclient import TestClient

from api import app

client = TestClient(app)


def test_health_endpoint() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    payload = response.json()
    assert payload["demo_mode_available"] is True


def test_demo_audit_endpoint() -> None:
    response = client.post("/demo/audits", json={"url": "https://example.com"})
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "completed"
    assert payload["execution_type"] == "demo"
    assert payload["overall_score"] == 72
