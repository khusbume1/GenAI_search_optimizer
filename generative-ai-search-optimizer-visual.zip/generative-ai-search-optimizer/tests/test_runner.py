from pathlib import Path

import pytest

from geo_optimizer.config import Settings
from geo_optimizer.runner import ClaudeGeoRunner, build_geo_prompt, normalize_url
from geo_optimizer.storage import AuditStore


def test_normalize_url_adds_https() -> None:
    url, domain = normalize_url("Example.com/path#fragment")
    assert url == "https://Example.com/path"
    assert domain == "example.com"


@pytest.mark.parametrize(
    "url",
    [
        "http://localhost:8000",
        "http://127.0.0.1",
        "http://192.168.1.10",
        "http://user:pass@example.com",
    ],
)
def test_normalize_url_rejects_non_public_targets(url: str) -> None:
    with pytest.raises(ValueError):
        normalize_url(url)


def test_build_prompt_maps_mode() -> None:
    prompt = build_geo_prompt("https://example.com", "schema")
    assert prompt.startswith("/geo schema https://example.com")
    assert "Do not modify the target website" in prompt


def test_demo_run_creates_traceable_artifacts(tmp_path: Path) -> None:
    project_root = Path(__file__).resolve().parents[1]
    data_dir = tmp_path / "data"
    settings = Settings(
        project_root=project_root,
        data_dir=data_dir,
        database_path=data_dir / "audit.db",
        runs_dir=data_dir / "runs",
        claude_bin="claude",
        claude_extra_args=(),
        timeout_seconds=60,
    )
    settings.runs_dir.mkdir(parents=True)
    store = AuditStore(settings.database_path)
    runner = ClaudeGeoRunner(settings, store)

    result = runner.run_demo("https://example.com")

    assert result.status == "completed"
    assert result.execution_type == "demo"
    assert result.overall_score == 72
    assert result.findings
    run_dir = Path(result.run_dir)
    assert (run_dir / "audit-request.json").exists()
    assert (run_dir / "audit-result.json").exists()
    assert (run_dir / "GEO-AUDIT-REPORT.md").exists()
    stored = store.get(result.audit_id)
    assert stored is not None
    assert stored["execution_type"] == "demo"
    assert stored["overall_score"] == 72
