#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required." >&2
  exit 1
fi

if ! command -v claude >/dev/null 2>&1; then
  echo "Claude Code CLI is required. Install and authenticate it before running audits." >&2
  exit 1
fi

python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[dev]'

mkdir -p vendor
if [ ! -d vendor/geo-seo-claude/.git ]; then
  git clone --depth 1 https://github.com/zubair-trabzada/geo-seo-claude.git vendor/geo-seo-claude
else
  git -C vendor/geo-seo-claude pull --ff-only
fi

# Install from the reviewed local checkout rather than piping a remote script directly to a shell.
bash vendor/geo-seo-claude/install.sh

echo
echo "Setup complete. Run:"
echo "  source .venv/bin/activate"
echo "  geo-search doctor"
echo "  streamlit run dashboard.py"
