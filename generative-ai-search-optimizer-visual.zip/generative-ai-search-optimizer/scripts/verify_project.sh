#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python -m compileall -q geo_optimizer api.py dashboard.py
ruff check .
pytest -q

TEMP_DATA="$(mktemp -d)"
trap 'rm -rf "$TEMP_DATA"' EXIT
GEO_DATA_DIR="$TEMP_DATA" geo-search demo --url https://example.com >/dev/null

echo "Project verification passed."
