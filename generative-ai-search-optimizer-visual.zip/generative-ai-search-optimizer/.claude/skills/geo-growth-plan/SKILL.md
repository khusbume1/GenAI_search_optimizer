---
name: geo-growth-plan
description: Converts a completed GEO audit into an implementation-ready backlog, content plan, schema plan, and measurement framework. Use after a /geo audit or when the user asks how to implement GEO recommendations.
argument-hint: "[path-to-GEO-AUDIT-REPORT.md]"
disable-model-invocation: true
allowed-tools: Read Write Glob Grep
---

# GEO Growth Plan

Turn the audit report at `$ARGUMENTS` into a practical delivery plan.

## Required workflow

1. Read the complete audit report. Do not invent findings that are absent from it.
2. Extract the current overall score, category scores, critical/high findings, quick wins, and business type.
3. Create `GEO-IMPLEMENTATION-PLAN.md` beside the source report.
4. Organize recommendations into:
   - Immediate fixes: 0-7 days
   - Foundation work: 8-30 days
   - Authority and content growth: 31-90 days
5. For every backlog item include:
   - Problem and supporting audit evidence
   - Exact page or page type affected
   - Recommended change
   - Owner role
   - Effort: S, M, or L
   - Expected GEO category affected
   - Acceptance criteria
   - Measurement metric
6. Include separate sections for:
   - Technical/crawler work
   - Citability and answer-block rewrites
   - E-E-A-T improvements
   - Schema/JSON-LD changes
   - Brand/entity authority
   - Platform-specific actions
7. End with a monthly re-audit scorecard. Never promise a ranking or citation outcome.
