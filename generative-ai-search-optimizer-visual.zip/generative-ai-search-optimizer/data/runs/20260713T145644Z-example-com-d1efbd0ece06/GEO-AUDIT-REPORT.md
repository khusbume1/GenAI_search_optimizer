# GEO Audit Report: example.com

**Audit URL:** https://example.com  
**Audit Type:** Full Generative Engine Optimization audit  
**Generated For:** Portfolio demonstration  

## Executive Summary

**Overall GEO Score: 72/100 (Fair)**

The website has a solid technical foundation, but its content is not consistently structured for direct quotation by generative search systems. The highest-impact opportunities are clearer answer-first content blocks, stronger organization and author entities, expanded structured data, and explicit access guidance for AI crawlers.

### Score Breakdown

| Category | Score | Weight | Weighted Score |
|---|---:|---:|---:|
| AI Citability | 64/100 | 25% | 16.0 |
| Brand Authority | 58/100 | 20% | 11.6 |
| Content E-E-A-T | 76/100 | 20% | 15.2 |
| Technical GEO | 86/100 | 15% | 12.9 |
| Schema & Structured Data | 70/100 | 10% | 7.0 |
| Platform Optimization | 66/100 | 10% | 6.6 |

## Critical Issues (Fix Immediately)

No critical technical blockers were detected in this demonstration report.

## High Priority Issues

### Key pages do not provide concise answer-first passages
- Important service pages begin with marketing language instead of a direct definition or answer.
- Add self-contained summary passages that clearly explain the service, audience, process, and differentiators.

### Organization and author entities are incomplete
- The site does not consistently connect Organization, Person, Article, and sameAs properties.
- Add validated JSON-LD and visible author credentials to improve entity clarity.

## Medium Priority Issues

### AI crawler policy is not explicit
- Review robots.txt and document the intended policy for major AI user agents.
- Avoid accidental blocking while maintaining the organization’s data-use policy.

### Content evidence and update signals are inconsistent
- Some articles lack references, reviewed dates, named experts, or methodology notes.
- Add source attribution and visible update information where appropriate.

## Low Priority Issues

### llms.txt is not available
- Consider publishing a concise llms.txt file that identifies important public resources and preferred canonical pages.

## Recommended 30-Day Actions

1. Rewrite the top five commercial pages with direct answer blocks and descriptive headings.
2. Add Organization and Person JSON-LD with consistent identifiers and sameAs references.
3. Review robots.txt for AI crawler access and document the chosen policy.
4. Add evidence, author review, and freshness signals to priority knowledge articles.
5. Re-run the audit and compare category-level score changes.

## Measurement Plan

Track the GEO score, category scores, indexed structured-data errors, AI crawler access status, number of answer-first passages, and verified brand/entity references. Treat these as diagnostic metrics rather than guarantees of rankings or citations.
