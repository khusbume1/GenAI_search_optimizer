# Publish the Project to GitHub

## 1. Create an empty repository

On GitHub, create a repository such as:

```text
generative-ai-search-optimizer
```

Recommended description:

```text
Claude-powered Generative Engine Optimization platform with FastAPI, Streamlit, SQLite, structured report parsing, comparison, and reproducible demo audits.
```

Do not initialize the GitHub repository with another README, license, or `.gitignore`, because those files are already included.

## 2. Personalize the files

Before pushing:

1. Replace `OWNER/REPOSITORY` in `README.md` with your GitHub username and repository name.
2. Review the author name in `pyproject.toml` and `NOTICE`.
3. Add contact links only when you want them public.
4. Keep the upstream attribution section.

## 3. Verify locally

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
pytest -q
ruff check .
geo-search demo --url https://example.com
```

## 4. Initialize Git and push

```bash
git init
git add .
git commit -m "Build Claude-powered GEO audit platform"
git branch -M main
git remote add origin https://github.com/OWNER/REPOSITORY.git
git push -u origin main
```

## 5. Configure the repository page

Add these topics:

```text
generative-ai
geo
seo
claude
claude-code
python
fastapi
streamlit
sqlite
ai-search
llm
```

Enable GitHub Actions so the CI badge shows test status.

## 6. Add a demonstration image

After running Streamlit, replace the included illustrative preview with a real screenshot showing:

- Overall score
- Category chart
- Actionable findings
- Audit history

Store it under `docs/assets/dashboard.png` and add this line near the top of the README:

```text
Dashboard image path: docs/assets/dashboard.png
```

## 7. Protect private data

Do not commit:

- `.env`
- `.venv/`
- `vendor/`
- `data/geo_optimizer.db`
- Real client reports
- Claude credentials or tokens

The included `.gitignore` already excludes these paths.
