# Setup and Run Guide

## Option A: local demo

This option demonstrates the entire application except live Claude execution.

```bash
git clone https://github.com/OWNER/REPOSITORY.git
cd REPOSITORY
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[dev]'
geo-search demo --url https://example.com
```

Windows Git Bash activation:

```bash
source .venv/Scripts/activate
```

Launch the dashboard:

```bash
streamlit run dashboard.py
```

Launch the API:

```bash
uvicorn api:app --reload
```

## Option B: live Claude GEO audits

Review and run:

```bash
./scripts/bootstrap.sh
source .venv/bin/activate
geo-search doctor
```

The script:

1. Checks Python and Claude Code.
2. Creates `.venv`.
3. Installs this application and development tools.
4. Clones the upstream repository to `vendor/geo-seo-claude`.
5. Runs the upstream installer from the reviewed local checkout.

Run an audit:

```bash
geo-search audit https://example.com --mode full
```

## Environment variables

Copy `.env.example` values into your shell or environment manager.

| Variable | Default | Description |
|---|---|---|
| `GEO_DATA_DIR` | `./data` | Base directory for database and run files |
| `GEO_DATABASE_PATH` | `./data/geo_optimizer.db` | SQLite path |
| `GEO_CLAUDE_BIN` | `claude` | Claude Code executable |
| `GEO_AUDIT_TIMEOUT_SECONDS` | `1800` | Maximum live audit runtime |
| `GEO_CLAUDE_EXTRA_ARGS` | empty | Optional extra CLI arguments |

## Troubleshooting

### Claude command not found

Install and authenticate Claude Code, then confirm:

```bash
claude --version
```

### GEO skill not installed

Run the bootstrap script or manually install the upstream project. Then check:

```bash
ls ~/.claude/skills/geo/SKILL.md
```

### Parser returns no score

Open the report and confirm that it contains an `Overall GEO Score` and a Markdown category table. Add a parser test before changing the extraction logic.

### Empty dashboard

Run:

```bash
geo-search demo --url https://example.com
```

Then refresh Streamlit.
