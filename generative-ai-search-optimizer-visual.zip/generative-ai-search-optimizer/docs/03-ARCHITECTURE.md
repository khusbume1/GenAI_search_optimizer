# Architecture

## Component diagram

<p align="center">
  <img src="assets/system-architecture.svg" alt="Layered component architecture" width="780">
</p>

The color groups show clear technical boundaries: blue for user-facing interfaces, purple for application orchestration, pink for AI execution, amber for deterministic structuring, and green for persisted outputs.

## Audit lifecycle

<p align="center">
  <img src="assets/audit-lifecycle.svg" alt="Audit execution lifecycle" width="1100">
</p>

The lifecycle is deliberately traceable: each request receives a unique audit ID before execution, and all generated artifacts retain that identifier through parsing and persistence.

## Module responsibilities

### `runner.py`

- Validates modes and URLs
- Creates run directories
- Writes request metadata
- Invokes Claude Code
- Handles timeout and process failures
- Discovers report files
- Coordinates parsing and storage
- Supports local demo execution

### `parser.py`

- Normalizes report labels
- Extracts score and rating
- Extracts category values from Markdown tables
- Extracts severity sections and individual findings
- Returns a typed `ParsedReport`

### `storage.py`

- Creates and migrates the SQLite table
- Records running, completed, and failed audits
- Serializes categories and findings to JSON
- Supports history and domain filtering

### Interfaces

All interfaces use the same initialized `runner` and `store` from `service.py`. This prevents business logic from being duplicated across CLI, API, and UI.

## Deployment boundaries

The portfolio version is a single-process local application. A production architecture should separate:

- API service
- Background audit workers
- Postgres database
- Object storage for reports
- Authentication service
- Scheduler for repeat audits
- Monitoring and centralized logs
