# API Reference

Base URL for local development:

```text
http://127.0.0.1:8000
```

## `GET /health`

Returns live-audit readiness and demo availability.

## `POST /demo/audits`

Runs a complete local demonstration using the bundled report.

Request:

```json
{
  "url": "https://example.com"
}
```

## `POST /audits`

Runs a live Claude GEO audit.

Request:

```json
{
  "url": "https://example.com",
  "mode": "full"
}
```

Possible errors:

- `400`: unsupported mode or invalid request
- `500`: Claude environment, execution, timeout, or report-processing failure

## `POST /comparisons`

Runs multiple audits and returns score-ranked results.

```json
{
  "urls": [
    "https://example.com",
    "https://competitor.com"
  ],
  "mode": "full",
  "demo": false
}
```

Set `demo` to `true` for local demonstration.

## `GET /audits`

Query parameters:

- `limit`: 1–500, default 50
- `domain`: optional exact domain filter

## `GET /audits/{audit_id}`

Returns a stored audit or `404` when it does not exist.

## OpenAPI

FastAPI automatically exposes:

- Swagger UI: `/docs`
- ReDoc: `/redoc`
- OpenAPI JSON: `/openapi.json`
