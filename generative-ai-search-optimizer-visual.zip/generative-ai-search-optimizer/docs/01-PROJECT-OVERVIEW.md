# Project Overview

## 1. Problem statement

Web teams increasingly need to understand whether their content can be interpreted and quoted by generative search systems, not only whether it satisfies traditional SEO checks. A Claude GEO skill can produce an audit, but a raw command is difficult to demonstrate, track, compare, or integrate into another system.

## 2. Project objective

The goal is to convert the skill into a reusable application that:

1. Accepts a public website URL and an audit type.
2. Runs the correct Claude GEO workflow.
3. Captures the generated report.
4. Converts narrative Markdown into structured data.
5. Stores every audit for later comparison.
6. Presents results through a CLI, API, and dashboard.
7. Produces a delivery-ready optimization plan.

## 3. Target users

- SEO and content specialists
- Digital marketing teams
- AI product managers
- Consultants delivering website audits
- Developers evaluating structured content and crawler access

## 4. Functional scope

### Included

- URL validation
- Multiple audit modes
- Claude Code orchestration
- Demo mode
- Markdown report parsing
- SQLite persistence
- Audit history
- Multi-site comparison
- REST API
- Streamlit dashboard
- Automated tests
- GitHub Actions CI

### Deliberately excluded

- Automatic modification of client websites
- Guaranteed ranking or citation predictions
- Multi-tenant authentication
- Background worker infrastructure
- Billing and subscription management

## 5. Technology choices

| Technology | Purpose |
|---|---|
| Python | Core application language |
| Claude Code | Executes the installed GEO skill |
| FastAPI | REST API and OpenAPI documentation |
| Streamlit | Interactive portfolio dashboard |
| SQLite | Local persistence with minimal setup |
| pytest | Automated testing |
| Ruff | Static linting and import checks |
| GitHub Actions | Continuous integration |

## 6. Success criteria

The project is successful when a reviewer can:

- Clone the repository
- Install it locally
- Run a demo audit without credentials
- View structured scores and findings
- Inspect the original input and generated output files
- Start the dashboard or API
- Understand the design from the documentation
