# Portfolio Presentation Guide

## Project title

**Generative AI Search Optimizer — Claude-Powered GEO Audit Platform**

## One-line description

A Python platform that converts Claude GEO skills into a repeatable website-audit product with structured scoring, actionable findings, history tracking, comparison, an API, and an interactive dashboard.

## CV bullet

- Developed a **Generative Engine Optimization platform** using **Claude Code Skills, Python, FastAPI, Streamlit, and SQLite** to validate website inputs, orchestrate AI-search audits, parse generated reports into structured scores and findings, benchmark domains, and produce traceable optimization roadmaps.

## Three interview talking points

### 1. Productization

I did not stop at running an AI prompt. I wrapped the skill in an application layer with repeatable inputs, structured outputs, persistence, error handling, APIs, and a UI.

### 2. AI-to-software boundary

The model produces a Markdown audit, while deterministic Python code validates inputs, controls execution, parses the report, stores results, and exposes a stable contract to users.

### 3. Reproducibility

Every audit receives a unique ID and isolated directory containing the original request, raw execution output, source report, and structured result. I also added demo mode so reviewers can evaluate the project without credentials.

## Suggested GitHub repository description

```text
Claude-powered Generative Engine Optimization platform with FastAPI, Streamlit, SQLite, report parsing, competitor comparison, and reproducible demo audits.
```

## Suggested GitHub topics

```text
generative-ai, geo, seo, claude, claude-code, python, fastapi, streamlit, sqlite, ai-search, llm
```

## Demo script for an interview

1. Open the README and explain the Input → Process → Output flow.
2. Run `geo-search demo --url https://example.com`.
3. Show the created `audit-request.json` and `audit-result.json`.
4. Launch Streamlit and explain the score, findings, and history.
5. Open `/docs` in FastAPI and demonstrate the demo endpoint.
6. Explain how live mode replaces the sample report with Claude `/geo` execution.
7. Close with the production roadmap and responsible-use controls.

## What this project demonstrates

- AI workflow orchestration
- Backend API design
- Data modeling and persistence
- Markdown-to-structured-data parsing
- Interactive data applications
- Input validation and operational safety
- Automated testing and CI
- Technical documentation and system design
