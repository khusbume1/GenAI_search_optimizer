# Input, Process, and Output

<p align="center">
  <img src="assets/geo-workflow.svg" alt="End-to-end input, process, and output workflow" width="900">
</p>

<p align="center"><em>The complete data journey from website submission to a structured GEO scorecard and implementation-ready findings.</em></p>

## Input

### Primary input

A public website URL:

```text
https://example.com
```

The runner adds `https://` when the scheme is missing and removes URL fragments. It rejects:

- Unsupported schemes
- Localhost targets
- Embedded usernames or passwords
- Private, loopback, link-local, or reserved IP literals

### Audit mode

| Application mode | Claude command | Intended use |
|---|---|---|
| `full` | `/geo audit` | Complete GEO and SEO assessment |
| `quick` | `/geo quick` | Fast visibility snapshot |
| `citability` | `/geo citability` | Citation-readiness analysis |
| `crawlers` | `/geo crawlers` | AI crawler and robots policy |
| `llmstxt` | `/geo llmstxt` | llms.txt assessment or generation |
| `brands` | `/geo brands` | Brand/entity mention analysis |
| `platforms` | `/geo platforms` | Platform-specific readiness |
| `schema` | `/geo schema` | Structured-data analysis |
| `technical` | `/geo technical` | Technical SEO/GEO foundations |
| `content` | `/geo content` | Content quality and E-E-A-T |
| `report` | `/geo report` | Client-ready report workflow |

### Example API input

```json
{
  "url": "https://example.com",
  "mode": "full"
}
```

## Process

### Step 1: validate and normalize

`normalize_url()` converts the user input into a consistent URL and domain. This prevents unsupported or obviously unsafe local targets from reaching the orchestration layer.

### Step 2: initialize an audit

The runner generates:

- A 12-character audit ID
- A UTC timestamp
- A unique run directory
- A `running` database record
- An `audit-request.json` file

### Step 3: choose live or demo execution

#### Live

The runner builds a controlled prompt such as:

```text
/geo audit https://example.com
```

It invokes Claude Code with a timeout, captures standard output and error, and records the process exit code.

#### Demo

The runner copies the bundled sample report into the run directory. This exercises the parser, persistence, API, CLI, and dashboard without external credentials or network access.

### Step 4: discover the report

The runner first searches for the expected filename for the selected mode. When it is not present, it searches for recently modified `GEO-*.md`, PDF, or `llms.txt` files.

### Step 5: parse the report

The parser extracts:

- Overall score
- Rating
- Category scores
- Executive summary
- Individual findings
- Severity counts

The parser maps similar category labels to canonical names so the UI remains consistent.

### Step 6: persist and export

The application updates the SQLite audit row and writes `audit-result.json` to the run directory.

### Step 7: present results

The same stored result is consumed by:

- The CLI for terminal workflows
- FastAPI for integrations
- Streamlit for visualization
- The project Claude skill for implementation planning

## Output

### File output

```text
run-directory/
├── audit-request.json
├── claude-output.txt        # live execution only
├── GEO-AUDIT-REPORT.md
└── audit-result.json
```

### Database output

The `audits` table stores:

- Identity and URL fields
- Mode and execution type
- Status and timestamps
- Report location
- Overall score and rating
- Categories as JSON
- Severity counts as JSON
- Findings as JSON
- Summary, raw output, and errors

### API output

```json
{
  "audit_id": "3b52a781d3f1",
  "url": "https://example.com",
  "domain": "example.com",
  "mode": "full",
  "status": "completed",
  "execution_type": "demo",
  "overall_score": 72.0,
  "rating": "Fair",
  "categories": {
    "AI Citability": 64.0,
    "Technical GEO": 86.0
  },
  "findings": [
    {
      "severity": "high",
      "title": "Key pages do not provide concise answer-first passages",
      "details": "..."
    }
  ]
}
```

## Traceability

The input file, raw execution output, generated report, structured result, and database record share the same audit ID and run directory. This makes every displayed score traceable to its source report.
