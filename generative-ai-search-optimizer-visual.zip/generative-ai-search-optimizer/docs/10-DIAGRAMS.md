# Diagram Assets

The repository uses editable **Graphviz DOT** files and generated **SVG** files for technical diagrams.

## Included diagrams

| Diagram | Editable source | GitHub asset |
|---|---|---|
| Input, process, and output | `docs/assets/geo-workflow.dot` | `docs/assets/geo-workflow.svg` |
| Layered system architecture | `docs/assets/system-architecture.dot` | `docs/assets/system-architecture.svg` |
| Audit lifecycle | `docs/assets/audit-lifecycle.dot` | `docs/assets/audit-lifecycle.svg` |
| Continuous-integration pipeline | `docs/assets/ci-pipeline.dot` | `docs/assets/ci-pipeline.svg` |

The SVG files are referenced by the README and documentation because they remain sharp at different screen sizes and render directly on GitHub.

## Regenerating a diagram

Install Graphviz, modify the corresponding `.dot` file, and run:

```bash
dot -Tsvg docs/assets/system-architecture.dot \
  -o docs/assets/system-architecture.svg
```

Use the same pattern for the other diagrams. The PNG files are optional preview or fallback assets.

## Visual language

- **Blue:** user-facing presentation interfaces
- **Purple:** application orchestration and validation
- **Pink:** Claude and GEO analysis execution
- **Amber:** deterministic parsing and typed structuring
- **Green:** persistence, scorecards, and delivered results

The diagrams intentionally separate generative AI responsibilities from deterministic application responsibilities. This makes the system easier to explain, test, and extend.
