# Design Decisions

## Why use an external Claude skill?

The upstream project already contains the domain-specific GEO workflow. This project focuses on integration and product engineering rather than duplicating that intellectual work. The separation also makes ownership and attribution clear.

## Why keep AI output in Markdown?

Markdown is readable by consultants and clients, easy for Claude to generate, and suitable for versioning. The parser converts stable sections into structured fields required by software interfaces.

## Why also write JSON?

`audit-result.json` creates a machine-readable artifact that can be consumed without opening SQLite. It is useful for debugging, integrations, demonstrations, and future object-storage workflows.

## Why SQLite?

SQLite has no server dependency and is appropriate for a portfolio application. The storage class isolates database operations so Postgres can replace it later.

## Why synchronous execution?

Synchronous execution keeps the MVP understandable. The API documentation clearly identifies a queue worker as a production improvement because live audits can take longer than normal HTTP requests.

## Why per-run directories?

They provide:

- Isolation between audits
- Reproducibility
- Simple report discovery
- Easier debugging
- Clear traceability from request to result

## Why demo mode?

A portfolio reviewer should not need a paid account, model authentication, or permission to crawl a website. Demo mode exercises the complete deterministic application path while being explicit that no live audit occurred.

## Why reject local and private IP targets?

The application should only process public website URLs. This validation reduces accidental access to local resources. A production version would also resolve hostnames and enforce egress policies at the network layer.

## Why not automatically publish recommendations?

AI-generated schema or content can be incorrect or unsuitable. The system produces recommendations and implementation plans but keeps deployment under human review.
