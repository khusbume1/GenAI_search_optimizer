from __future__ import annotations

from .config import load_settings
from .runner import ClaudeGeoRunner
from .storage import AuditStore

settings = load_settings()
store = AuditStore(settings.database_path)
runner = ClaudeGeoRunner(settings, store)
