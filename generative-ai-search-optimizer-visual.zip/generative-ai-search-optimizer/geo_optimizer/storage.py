from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from .models import AuditFinding


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class AuditStore:
    def __init__(self, database_path: Path):
        self.database_path = database_path
        self._initialize()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.database_path)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS audits (
                    id TEXT PRIMARY KEY,
                    url TEXT NOT NULL,
                    domain TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    execution_type TEXT NOT NULL DEFAULT 'live',
                    status TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    completed_at TEXT,
                    run_dir TEXT NOT NULL,
                    report_path TEXT,
                    overall_score REAL,
                    rating TEXT,
                    categories_json TEXT NOT NULL DEFAULT '{}',
                    severity_json TEXT NOT NULL DEFAULT '{}',
                    findings_json TEXT NOT NULL DEFAULT '[]',
                    summary TEXT NOT NULL DEFAULT '',
                    stdout TEXT NOT NULL DEFAULT '',
                    error TEXT
                )
                """
            )
            columns = {
                row[1] for row in connection.execute("PRAGMA table_info(audits)").fetchall()
            }
            if "execution_type" not in columns:
                connection.execute(
                    "ALTER TABLE audits ADD COLUMN execution_type TEXT NOT NULL DEFAULT 'live'"
                )
            if "findings_json" not in columns:
                connection.execute(
                    "ALTER TABLE audits ADD COLUMN findings_json TEXT NOT NULL DEFAULT '[]'"
                )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_audits_domain_started "
                "ON audits(domain, started_at DESC)"
            )

    def create(
        self,
        audit_id: str,
        url: str,
        domain: str,
        mode: str,
        run_dir: str,
        execution_type: str = "live",
    ) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO audits(
                    id, url, domain, mode, execution_type, status, started_at, run_dir
                ) VALUES (?, ?, ?, ?, ?, 'running', ?, ?)
                """,
                (audit_id, url, domain, mode, execution_type, utc_now(), run_dir),
            )

    def complete(
        self,
        audit_id: str,
        *,
        report_path: str | None,
        overall_score: float | None,
        rating: str | None,
        categories: dict[str, float],
        severity_counts: dict[str, int],
        findings: list[AuditFinding],
        summary: str,
        stdout: str,
    ) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                UPDATE audits
                SET status='completed', completed_at=?, report_path=?, overall_score=?,
                    rating=?, categories_json=?, severity_json=?, findings_json=?,
                    summary=?, stdout=?, error=NULL
                WHERE id=?
                """,
                (
                    utc_now(),
                    report_path,
                    overall_score,
                    rating,
                    json.dumps(categories, sort_keys=True),
                    json.dumps(severity_counts, sort_keys=True),
                    json.dumps([finding.as_dict() for finding in findings]),
                    summary,
                    stdout,
                    audit_id,
                ),
            )

    def fail(self, audit_id: str, error: str, stdout: str = "") -> None:
        with self._connect() as connection:
            connection.execute(
                """
                UPDATE audits
                SET status='failed', completed_at=?, error=?, stdout=?
                WHERE id=?
                """,
                (utc_now(), error, stdout, audit_id),
            )

    def get(self, audit_id: str) -> dict | None:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM audits WHERE id=?", (audit_id,)).fetchone()
        return self._deserialize(row) if row else None

    def list(self, *, limit: int = 50, domain: str | None = None) -> list[dict]:
        query = "SELECT * FROM audits"
        params: list[object] = []
        if domain:
            query += " WHERE domain=?"
            params.append(domain)
        query += " ORDER BY started_at DESC LIMIT ?"
        params.append(max(1, min(limit, 500)))
        with self._connect() as connection:
            rows = connection.execute(query, params).fetchall()
        return [self._deserialize(row) for row in rows]

    @staticmethod
    def _deserialize(row: sqlite3.Row) -> dict:
        item = dict(row)
        item["categories"] = json.loads(item.pop("categories_json") or "{}")
        item["severity_counts"] = json.loads(item.pop("severity_json") or "{}")
        item["findings"] = json.loads(item.pop("findings_json") or "[]")
        return item
