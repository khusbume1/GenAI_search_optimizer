from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .parser import parse_report_file
from .runner import SUPPORTED_MODES, normalize_url
from .service import runner, store


def _print_json(value: object) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False, default=str))


def command_audit(args: argparse.Namespace) -> int:
    result = runner.run(args.url, args.mode)
    _print_json(result.as_dict())
    return 0 if result.status == "completed" else 1


def command_demo(args: argparse.Namespace) -> int:
    result = runner.run_demo(args.url)
    _print_json(result.as_dict())
    return 0 if result.status == "completed" else 1


def command_compare(args: argparse.Namespace) -> int:
    execute = runner.run_demo if args.demo else lambda url: runner.run(url, args.mode)
    results = [execute(url).as_dict() for url in args.urls]
    ranked = sorted(
        results,
        key=lambda item: item["overall_score"] if item["overall_score"] is not None else -1,
        reverse=True,
    )
    _print_json({"mode": args.mode, "demo": args.demo, "results": ranked})
    return 0 if all(item["status"] == "completed" for item in results) else 1


def command_history(args: argparse.Namespace) -> int:
    domain = None
    if args.domain:
        _, domain = normalize_url(args.domain)
    _print_json(store.list(limit=args.limit, domain=domain))
    return 0


def command_show(args: argparse.Namespace) -> int:
    item = store.get(args.audit_id)
    if not item:
        print(f"Audit not found: {args.audit_id}", file=sys.stderr)
        return 1
    _print_json(item)
    return 0


def command_import(args: argparse.Namespace) -> int:
    path = Path(args.path).expanduser().resolve()
    if not path.exists():
        print(f"Report not found: {path}", file=sys.stderr)
        return 1
    parsed = parse_report_file(path)
    _print_json(
        {
            "overall_score": parsed.overall_score,
            "rating": parsed.rating,
            "categories": parsed.categories,
            "summary": parsed.summary,
            "severity_counts": parsed.severity_counts,
            "findings": [finding.as_dict() for finding in parsed.findings],
        }
    )
    return 0


def command_doctor(_: argparse.Namespace) -> int:
    issues = runner.check_environment()
    payload = {
        "ready_for_live_audits": not issues,
        "demo_mode_available": True,
        "issues": issues,
        "database": str(store.database_path),
        "supported_modes": list(SUPPORTED_MODES),
    }
    _print_json(payload)
    return 0 if not issues else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="geo-search",
        description="Run and manage Claude-powered GEO audits.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    audit = subparsers.add_parser("audit", help="Run a live audit for one website")
    audit.add_argument("url")
    audit.add_argument("--mode", choices=SUPPORTED_MODES, default="full")
    audit.set_defaults(func=command_audit)

    demo = subparsers.add_parser("demo", help="Run a local sample audit without Claude")
    demo.add_argument("--url", default="https://example.com")
    demo.set_defaults(func=command_demo)

    compare = subparsers.add_parser("compare", help="Audit and rank several websites")
    compare.add_argument("urls", nargs="+", help="Two or more website URLs")
    compare.add_argument("--mode", choices=SUPPORTED_MODES, default="full")
    compare.add_argument("--demo", action="store_true", help="Use bundled sample data")
    compare.set_defaults(func=command_compare)

    history = subparsers.add_parser("history", help="List previous audits")
    history.add_argument("--domain", help="Optional domain or URL filter")
    history.add_argument("--limit", type=int, default=20)
    history.set_defaults(func=command_history)

    show = subparsers.add_parser("show", help="Show a stored audit")
    show.add_argument("audit_id")
    show.set_defaults(func=command_show)

    import_report = subparsers.add_parser("parse-report", help="Parse an existing report")
    import_report.add_argument("path")
    import_report.set_defaults(func=command_import)

    doctor = subparsers.add_parser("doctor", help="Check live-audit prerequisites")
    doctor.set_defaults(func=command_doctor)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    raise SystemExit(args.func(args))


if __name__ == "__main__":
    main()
