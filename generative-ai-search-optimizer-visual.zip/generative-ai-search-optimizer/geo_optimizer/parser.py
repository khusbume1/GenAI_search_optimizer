from __future__ import annotations

import re
from pathlib import Path

from .models import AuditFinding, ParsedReport

_CATEGORY_ALIASES = {
    "ai citability": "AI Citability",
    "ai citability & visibility": "AI Citability",
    "brand authority": "Brand Authority",
    "brand authority signals": "Brand Authority",
    "content e-e-a-t": "Content E-E-A-T",
    "content quality & e-e-a-t": "Content E-E-A-T",
    "technical geo": "Technical GEO",
    "technical foundations": "Technical GEO",
    "schema & structured data": "Schema & Structured Data",
    "structured data": "Schema & Structured Data",
    "platform optimization": "Platform Optimization",
}

_SEVERITY_HEADINGS = {
    "critical": "Critical Issues",
    "high": "High Priority Issues",
    "medium": "Medium Priority Issues",
    "low": "Low Priority Issues",
}


def _clean_markdown(value: str) -> str:
    value = re.sub(r"[*_`>#]", "", value)
    return re.sub(r"\s+", " ", value).strip()


def _extract_section(markdown: str, heading: str) -> str:
    pattern = rf"##\s+{re.escape(heading)}[^\n]*\n(.*?)(?=\n##\s|\Z)"
    match = re.search(pattern, markdown, flags=re.IGNORECASE | re.DOTALL)
    return match.group(1).strip() if match else ""


def _extract_summary(markdown: str) -> str:
    body = _extract_section(markdown, "Executive Summary")
    if not body:
        return ""
    body = re.sub(
        r"\*\*Overall GEO Score:.*?(?:\n|$)", "", body, flags=re.IGNORECASE
    )
    body = re.split(r"\n###\s+Score Breakdown", body, maxsplit=1, flags=re.IGNORECASE)[0]
    return _clean_markdown(body)


def _extract_findings(markdown: str) -> list[AuditFinding]:
    findings: list[AuditFinding] = []
    for severity, heading in _SEVERITY_HEADINGS.items():
        body = _extract_section(markdown, heading)
        if not body:
            continue

        current_title: str | None = None
        detail_lines: list[str] = []

        def flush_heading(finding_severity: str = severity) -> None:
            nonlocal current_title, detail_lines
            if current_title:
                findings.append(
                    AuditFinding(
                        severity=finding_severity,
                        title=_clean_markdown(current_title),
                        details=_clean_markdown(" ".join(detail_lines)),
                    )
                )
            current_title = None
            detail_lines = []

        for raw_line in body.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            subheading = re.match(r"^###\s+(.*)$", line)
            bullet = re.match(r"^(?:[-*+] |\d+[.)]\s+)(.*)$", line)
            if subheading:
                flush_heading()
                current_title = subheading.group(1)
            elif bullet:
                if current_title:
                    detail_lines.append(bullet.group(1))
                else:
                    findings.append(
                        AuditFinding(
                            severity=severity,
                            title=_clean_markdown(bullet.group(1)),
                        )
                    )
            elif current_title:
                detail_lines.append(line)
        flush_heading()
    return findings


def parse_report_text(markdown: str) -> ParsedReport:
    parsed = ParsedReport()

    score_patterns = [
        r"Overall GEO Score\s*:?\s*\*{0,2}\s*(\d+(?:\.\d+)?)\s*/\s*100(?:\s*\(([^)]+)\))?",
        r"\|\s*\*{0,2}Overall GEO Score\*{0,2}\s*\|.*?\*{0,2}(\d+(?:\.\d+)?)\s*/\s*100\*{0,2}",
    ]
    for pattern in score_patterns:
        match = re.search(pattern, markdown, flags=re.IGNORECASE)
        if match:
            parsed.overall_score = float(match.group(1))
            if match.lastindex and match.lastindex >= 2 and match.group(2):
                parsed.rating = _clean_markdown(match.group(2))
            break

    rating_match = re.search(
        r"Overall GEO Score.*?\((Excellent|Good|Fair|Poor|Critical)\)",
        markdown,
        flags=re.IGNORECASE,
    )
    if rating_match and not parsed.rating:
        parsed.rating = rating_match.group(1).title()

    for line in markdown.splitlines():
        if not line.lstrip().startswith("|"):
            continue
        cells = [_clean_markdown(cell) for cell in line.strip().strip("|").split("|")]
        if len(cells) < 2:
            continue
        canonical = _CATEGORY_ALIASES.get(cells[0].lower())
        if not canonical:
            continue
        score_match = re.search(r"(\d+(?:\.\d+)?)\s*(?:/\s*100)?", cells[1])
        if score_match:
            parsed.categories[canonical] = float(score_match.group(1))

    parsed.summary = _extract_summary(markdown)
    parsed.findings = _extract_findings(markdown)
    parsed.severity_counts = {
        severity: sum(1 for finding in parsed.findings if finding.severity == severity)
        for severity in _SEVERITY_HEADINGS
    }
    return parsed


def parse_report_file(path: Path) -> ParsedReport:
    return parse_report_text(path.read_text(encoding="utf-8", errors="replace"))
