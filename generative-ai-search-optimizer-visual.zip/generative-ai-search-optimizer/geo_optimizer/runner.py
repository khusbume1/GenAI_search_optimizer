from __future__ import annotations

import ipaddress
import json
import os
import re
import shutil
import subprocess
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

from .config import Settings
from .models import AuditResult
from .parser import parse_report_file, parse_report_text
from .storage import AuditStore

SUPPORTED_MODES = {
    "full": "audit",
    "quick": "quick",
    "citability": "citability",
    "crawlers": "crawlers",
    "llmstxt": "llmstxt",
    "brands": "brands",
    "platforms": "platforms",
    "schema": "schema",
    "technical": "technical",
    "content": "content",
    "report": "report",
}

EXPECTED_REPORTS = {
    "full": "GEO-AUDIT-REPORT.md",
    "citability": "GEO-CITABILITY-SCORE.md",
    "crawlers": "GEO-CRAWLER-ACCESS.md",
    "llmstxt": "llms.txt",
    "brands": "GEO-BRAND-MENTIONS.md",
    "platforms": "GEO-PLATFORM-OPTIMIZATION.md",
    "schema": "GEO-SCHEMA-REPORT.md",
    "technical": "GEO-TECHNICAL-AUDIT.md",
    "content": "GEO-CONTENT-ANALYSIS.md",
    "report": "GEO-CLIENT-REPORT.md",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize_url(raw_url: str) -> tuple[str, str]:
    candidate = raw_url.strip()
    if not re.match(r"^https?://", candidate, flags=re.IGNORECASE):
        candidate = f"https://{candidate}"
    parsed = urlparse(candidate)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Enter a valid public HTTP or HTTPS website URL")
    if parsed.username or parsed.password:
        raise ValueError("URLs containing embedded credentials are not supported")

    hostname = parsed.hostname.lower().rstrip(".")
    if hostname == "localhost" or hostname.endswith(".localhost"):
        raise ValueError("Localhost targets are not supported by this audit runner")
    try:
        address = ipaddress.ip_address(hostname)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise ValueError("Private, loopback, link-local, and reserved IP targets are not supported")

    normalized = parsed._replace(fragment="").geturl()
    return normalized, hostname


def build_geo_prompt(url: str, mode: str) -> str:
    if mode not in SUPPORTED_MODES:
        raise ValueError(f"Unsupported mode: {mode}")
    command_name = SUPPORTED_MODES[mode]
    return (
        f"/geo {command_name} {url}\n\n"
        "Run the requested GEO analysis now. Work only inside the current directory for generated "
        "reports. Respect robots.txt, rate limits, and the skill's crawl limits. Do not modify the target "
        "website. Finish by stating the output filename and the most important findings."
    )


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")[:80] or "site"


def _find_report(run_dir: Path, mode: str) -> Path | None:
    expected = EXPECTED_REPORTS.get(mode)
    if expected and (run_dir / expected).exists():
        return run_dir / expected

    candidates = sorted(
        [*run_dir.glob("GEO-*.md"), *run_dir.glob("*.pdf"), *run_dir.glob("llms.txt")],
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def _write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


class ClaudeGeoRunner:
    def __init__(self, settings: Settings, store: AuditStore):
        self.settings = settings
        self.store = store

    def check_environment(self) -> list[str]:
        issues: list[str] = []
        if not shutil.which(self.settings.claude_bin):
            issues.append(
                f"Claude Code CLI '{self.settings.claude_bin}' was not found in PATH."
            )
        skill_path = Path.home() / ".claude" / "skills" / "geo" / "SKILL.md"
        if not skill_path.exists():
            issues.append(
                "The upstream GEO skill is not installed at ~/.claude/skills/geo/SKILL.md."
            )
        return issues

    def _start_run(
        self, raw_url: str, mode: str, execution_type: str
    ) -> tuple[str, str, str, Path]:
        if mode not in SUPPORTED_MODES:
            raise ValueError(f"Unsupported mode: {mode}. Choose from {', '.join(SUPPORTED_MODES)}")
        url, domain = normalize_url(raw_url)
        audit_id = uuid.uuid4().hex[:12]
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        run_dir = self.settings.runs_dir / f"{timestamp}-{_slug(domain)}-{audit_id}"
        run_dir.mkdir(parents=True, exist_ok=False)
        self.store.create(
            audit_id, url, domain, mode, str(run_dir), execution_type=execution_type
        )
        return audit_id, url, domain, run_dir

    def _finish_run(
        self,
        *,
        audit_id: str,
        url: str,
        domain: str,
        mode: str,
        run_dir: Path,
        report_path: Path | None,
        parsed_source: str,
        stdout: str,
        execution_type: str,
    ) -> AuditResult:
        parsed = (
            parse_report_file(report_path)
            if report_path and report_path.suffix.lower() in {".md", ".txt"}
            else parse_report_text(parsed_source)
        )
        self.store.complete(
            audit_id,
            report_path=str(report_path) if report_path else None,
            overall_score=parsed.overall_score,
            rating=parsed.rating,
            categories=parsed.categories,
            severity_counts=parsed.severity_counts,
            findings=parsed.findings,
            summary=parsed.summary,
            stdout=stdout,
        )
        result = AuditResult(
            audit_id=audit_id,
            url=url,
            domain=domain,
            mode=mode,
            status="completed",
            execution_type=execution_type,
            run_dir=str(run_dir),
            report_path=str(report_path) if report_path else None,
            overall_score=parsed.overall_score,
            rating=parsed.rating,
            categories=parsed.categories,
            summary=parsed.summary,
            severity_counts=parsed.severity_counts,
            findings=parsed.findings,
            stdout=stdout,
        )
        _write_json(run_dir / "audit-result.json", result.as_dict())
        return result

    def run_demo(self, raw_url: str = "https://example.com") -> AuditResult:
        mode = "full"
        audit_id, url, domain, run_dir = self._start_run(raw_url, mode, "demo")
        source = self.settings.project_root / "examples" / "output" / "SAMPLE-GEO-AUDIT-REPORT.md"
        if not source.exists():
            error = f"Bundled demo report is missing: {source}"
            self.store.fail(audit_id, error)
            return AuditResult(
                audit_id=audit_id,
                url=url,
                domain=domain,
                mode=mode,
                status="failed",
                execution_type="demo",
                run_dir=str(run_dir),
                error=error,
            )

        report_path = run_dir / "GEO-AUDIT-REPORT.md"
        report_text = source.read_text(encoding="utf-8")
        report_path.write_text(
            report_text.replace("https://example.com", url).replace("example.com", domain),
            encoding="utf-8",
        )
        request_payload = {
            "audit_id": audit_id,
            "created_at": utc_now(),
            "execution_type": "demo",
            "url": url,
            "domain": domain,
            "mode": mode,
            "source_report": str(source.relative_to(self.settings.project_root)),
        }
        _write_json(run_dir / "audit-request.json", request_payload)
        return self._finish_run(
            audit_id=audit_id,
            url=url,
            domain=domain,
            mode=mode,
            run_dir=run_dir,
            report_path=report_path,
            parsed_source=report_text,
            stdout="Demo audit loaded from the bundled sample report. No external website was fetched.",
            execution_type="demo",
        )

    def run(self, raw_url: str, mode: str = "full") -> AuditResult:
        audit_id, url, domain, run_dir = self._start_run(raw_url, mode, "live")
        prompt = build_geo_prompt(url, mode)
        request_payload = {
            "audit_id": audit_id,
            "created_at": utc_now(),
            "execution_type": "live",
            "url": url,
            "domain": domain,
            "mode": mode,
            "claude_command": f"/geo {SUPPORTED_MODES[mode]} {url}",
        }
        _write_json(run_dir / "audit-request.json", request_payload)

        issues = self.check_environment()
        if issues:
            error = " ".join(issues)
            self.store.fail(audit_id, error)
            return AuditResult(
                audit_id=audit_id,
                url=url,
                domain=domain,
                mode=mode,
                status="failed",
                run_dir=str(run_dir),
                error=error,
            )

        command = [self.settings.claude_bin, "-p", prompt, *self.settings.claude_extra_args]
        env = os.environ.copy()
        env.setdefault("NO_COLOR", "1")

        stdout = ""
        try:
            completed = subprocess.run(
                command,
                cwd=run_dir,
                env=env,
                capture_output=True,
                text=True,
                timeout=self.settings.timeout_seconds,
                check=False,
            )
            stdout = (completed.stdout or "") + (completed.stderr or "")
            (run_dir / "claude-output.txt").write_text(stdout, encoding="utf-8")
            if completed.returncode != 0:
                error = f"Claude Code exited with status {completed.returncode}."
                self.store.fail(audit_id, error, stdout)
                return AuditResult(
                    audit_id=audit_id,
                    url=url,
                    domain=domain,
                    mode=mode,
                    status="failed",
                    run_dir=str(run_dir),
                    stdout=stdout,
                    error=error,
                )
        except subprocess.TimeoutExpired as exc:
            stdout = (exc.stdout or "") if isinstance(exc.stdout, str) else ""
            error = f"Audit exceeded the {self.settings.timeout_seconds}-second timeout."
            self.store.fail(audit_id, error, stdout)
            return AuditResult(
                audit_id=audit_id,
                url=url,
                domain=domain,
                mode=mode,
                status="failed",
                run_dir=str(run_dir),
                stdout=stdout,
                error=error,
            )
        except OSError as exc:
            error = f"Unable to start Claude Code: {exc}"
            self.store.fail(audit_id, error, stdout)
            return AuditResult(
                audit_id=audit_id,
                url=url,
                domain=domain,
                mode=mode,
                status="failed",
                run_dir=str(run_dir),
                stdout=stdout,
                error=error,
            )

        report_path = _find_report(run_dir, mode)
        return self._finish_run(
            audit_id=audit_id,
            url=url,
            domain=domain,
            mode=mode,
            run_dir=run_dir,
            report_path=report_path,
            parsed_source=stdout,
            stdout=stdout,
            execution_type="live",
        )
