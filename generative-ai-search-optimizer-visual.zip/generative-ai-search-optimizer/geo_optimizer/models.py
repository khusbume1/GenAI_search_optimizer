from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class AuditFinding:
    """One actionable issue extracted from a generated GEO report."""

    severity: str
    title: str
    details: str = ""

    def as_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass
class ParsedReport:
    overall_score: float | None = None
    rating: str | None = None
    categories: dict[str, float] = field(default_factory=dict)
    summary: str = ""
    severity_counts: dict[str, int] = field(default_factory=dict)
    findings: list[AuditFinding] = field(default_factory=list)


@dataclass
class AuditResult:
    audit_id: str
    url: str
    domain: str
    mode: str
    status: str
    run_dir: str
    report_path: str | None = None
    overall_score: float | None = None
    rating: str | None = None
    categories: dict[str, float] = field(default_factory=dict)
    summary: str = ""
    severity_counts: dict[str, int] = field(default_factory=dict)
    findings: list[AuditFinding] = field(default_factory=list)
    stdout: str = ""
    error: str | None = None
    execution_type: str = "live"

    def as_dict(self) -> dict[str, Any]:
        return {
            "audit_id": self.audit_id,
            "url": self.url,
            "domain": self.domain,
            "mode": self.mode,
            "status": self.status,
            "execution_type": self.execution_type,
            "run_dir": self.run_dir,
            "report_path": self.report_path,
            "overall_score": self.overall_score,
            "rating": self.rating,
            "categories": self.categories,
            "summary": self.summary,
            "severity_counts": self.severity_counts,
            "findings": [finding.as_dict() for finding in self.findings],
            "stdout": self.stdout,
            "error": self.error,
        }
