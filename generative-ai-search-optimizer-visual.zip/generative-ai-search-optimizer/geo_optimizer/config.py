from __future__ import annotations

import os
import shlex
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    project_root: Path
    data_dir: Path
    database_path: Path
    runs_dir: Path
    claude_bin: str
    claude_extra_args: tuple[str, ...]
    timeout_seconds: int


def _resolve_path(value: str | None, default: Path, root: Path) -> Path:
    path = Path(value).expanduser() if value else default
    if not path.is_absolute():
        path = root / path
    return path.resolve()


def load_settings() -> Settings:
    root = Path(__file__).resolve().parents[1]
    data_dir = _resolve_path(os.getenv("GEO_DATA_DIR"), root / "data", root)
    database_path = _resolve_path(
        os.getenv("GEO_DATABASE_PATH"), data_dir / "geo_optimizer.db", root
    )
    runs_dir = data_dir / "runs"
    timeout_raw = os.getenv("GEO_AUDIT_TIMEOUT_SECONDS", "1800")
    try:
        timeout_seconds = max(60, int(timeout_raw))
    except ValueError as exc:
        raise ValueError("GEO_AUDIT_TIMEOUT_SECONDS must be an integer") from exc

    extra_args = tuple(shlex.split(os.getenv("GEO_CLAUDE_EXTRA_ARGS", "")))

    data_dir.mkdir(parents=True, exist_ok=True)
    runs_dir.mkdir(parents=True, exist_ok=True)
    database_path.parent.mkdir(parents=True, exist_ok=True)

    return Settings(
        project_root=root,
        data_dir=data_dir,
        database_path=database_path,
        runs_dir=runs_dir,
        claude_bin=os.getenv("GEO_CLAUDE_BIN", "claude"),
        claude_extra_args=extra_args,
        timeout_seconds=timeout_seconds,
    )
